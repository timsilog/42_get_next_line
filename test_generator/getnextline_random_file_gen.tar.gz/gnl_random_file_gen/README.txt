How to generate files:
1) make
2) ./test.out <number of files to create>
3) cat -e toutA toutB toutC etc.

That's it!
